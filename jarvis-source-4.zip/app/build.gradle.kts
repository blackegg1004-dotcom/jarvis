plugins {
    id("com.android.application")
}

android {
    namespace = "com.jarvis.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jarvis.assistant"
        minSdk = 29
        targetSdk = 35
        versionCode = 4
        versionName = "2.1"
    }

    // 항상 같은 서명 → 다음 업데이트부터는 지우지 않고 덮어서 설치 가능 (키 설정도 유지됨)
    signingConfigs {
        create("fixed") {
            storeFile = file("jarvis.keystore")
            storePassword = "jarvis1234"
            keyAlias = "jarvis"
            keyPassword = "jarvis1234"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
