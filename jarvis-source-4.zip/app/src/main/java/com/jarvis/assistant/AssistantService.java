package com.jarvis.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AssistantService extends Service {

    public static final String ACTION_START = "start";
    public static final String ACTION_STOP = "stop";
    public static volatile boolean running = false;

    private static final String CH = "jarvis";
    private static final int C_BG = 0xF00A1420;

    private WindowManager wm;
    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    private ImageReader reader;
    private HandlerThread imgThread;
    private Handler imgHandler;
    private final Object imgLock = new Object();
    private Image latest;
    private int capW, capH, capDpi;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    private TextView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private LinearLayout panel;
    private WindowManager.LayoutParams panelLp;
    private TextView answer;
    private EditText question;
    private String mode = "auto";
    private final TextView[] modeTabs = new TextView[4];
    private volatile boolean busy = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(intent.getAction())) {
            startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            if (projection == null) {
                int code = intent.getIntExtra("code", 0);
                Intent data = intent.getParcelableExtra("data");
                MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                projection = mpm.getMediaProjection(code, data);
                if (projection == null) { stopSelf(); return START_NOT_STICKY; }
                setupCapture();
            }
            if (bubble == null) setupOverlay();
            running = true;
        }
        return START_NOT_STICKY;
    }

    // ================= 화면 캡처 =================
    private void setupCapture() {
        imgThread = new HandlerThread("capture");
        imgThread.start();
        imgHandler = new Handler(imgThread.getLooper());

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { main.post(AssistantService.this::stopSelf); }
        }, main);

        computeCaptureSize();
        reader = newReader();
        vdisplay = projection.createVirtualDisplay("jarvis", capW, capH, capDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, imgHandler);
    }

    private void computeCaptureSize() {
        WindowManager w = (WindowManager) getSystemService(WINDOW_SERVICE);
        int fw, fh;
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            Rect b = w.getMaximumWindowMetrics().getBounds();
            fw = b.width(); fh = b.height();
        } else {
            android.util.DisplayMetrics m = new android.util.DisplayMetrics();
            w.getDefaultDisplay().getRealMetrics(m);
            fw = m.widthPixels; fh = m.heightPixels;
        }
        // 절반 해상도로 캡처 (AI에는 충분하고 배터리를 아낌)
        capW = Math.max(2, fw / 2);
        capH = Math.max(2, fh / 2);
        capDpi = Math.max(1, getResources().getDisplayMetrics().densityDpi / 2);
    }

    private ImageReader newReader() {
        ImageReader r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3);
        r.setOnImageAvailableListener(rd -> {
            Image img = null;
            try { img = rd.acquireLatestImage(); } catch (Exception ignored) { }
            if (img == null) return;
            synchronized (imgLock) {
                if (latest != null) latest.close();
                latest = img;
            }
        }, imgHandler);
        return r;
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (vdisplay == null) return;
        // 가로/세로 회전 시 캡처 크기 다시 맞추기 (가로 게임 대응)
        int oldW = capW, oldH = capH;
        computeCaptureSize();
        if (oldW == capW && oldH == capH) return;
        ImageReader old = reader;
        reader = newReader();
        vdisplay.resize(capW, capH, capDpi);
        vdisplay.setSurface(reader.getSurface());
        synchronized (imgLock) { if (latest != null) { latest.close(); latest = null; } }
        imgHandler.post(old::close);
        resizePanel();
    }

    /** 가로/세로에 맞게 비서 창 크기를 다시 계산 (가로 게임에서 버튼이 화면 밖으로 나가지 않게) */
    private void resizePanel() {
        if (panelLp == null) return;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        panelLp.width = Math.min(screenW - dp(24), dp(460));
        panelLp.height = Math.min(dp(520), (int) (screenH * 0.85));
        if (panelShown()) try { wm.updateViewLayout(panel, panelLp); } catch (Exception ignored) { }
    }

    /** 캡처가 거의 전부 검은색이면 그 앱이 화면 캡처를 막은 것 (증권·은행 앱 등) */
    private static boolean isMostlyBlack(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight(), dark = 0, total = 0;
        for (int y = h / 10; y < h; y += Math.max(1, h / 20)) {
            for (int x = 0; x < w; x += Math.max(1, w / 20)) {
                int c = b.getPixel(x, y);
                int lum = ((c >> 16) & 0xFF) + ((c >> 8) & 0xFF) + (c & 0xFF);
                if (lum < 30) dark++;
                total++;
            }
        }
        return total > 0 && dark > total * 0.97;
    }

    static final String BLACK = "BLACK";

    /** 현재 화면을 JPEG base64로. 백그라운드 스레드에서 호출. */
    private String grabScreen() {
        Bitmap bmp;
        synchronized (imgLock) {
            if (latest == null) return null;
            Image.Plane pl = latest.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int pixelStride = pl.getPixelStride(), rowStride = pl.getRowStride();
            int w = latest.getWidth(), h = latest.getHeight();
            Bitmap full = Bitmap.createBitmap(rowStride / pixelStride, h, Bitmap.Config.ARGB_8888);
            buf.rewind();
            full.copyPixelsFromBuffer(buf);
            bmp = Bitmap.createBitmap(full, 0, 0, w, h);
            if (bmp != full) full.recycle();
        }
        if (isMostlyBlack(bmp)) { bmp.recycle(); return BLACK; }
        int max = Math.max(bmp.getWidth(), bmp.getHeight());
        if (max > 1280) {
            float s = 1280f / max;
            Bitmap sc = Bitmap.createScaledBitmap(bmp, Math.round(bmp.getWidth() * s), Math.round(bmp.getHeight() * s), true);
            bmp.recycle();
            bmp = sc;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 75, out);
        bmp.recycle();
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    // ================= 떠 있는 버튼 + 비서 창 =================
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void setupOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        bubble = new TextView(this);
        bubble.setText("J");
        bubble.setTextColor(0xFF0A1420);
        bubble.setTextSize(20);
        bubble.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xE022D3EE);
        bg.setStroke(dp(3), 0x80A5F3FC);
        bubble.setBackground(bg);
        bubble.setElevation(dp(6));

        bubbleLp = new WindowManager.LayoutParams(dp(54), dp(54),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = 0;
        bubbleLp.y = dp(200);
        bubble.setOnTouchListener(new BubbleTouch());
        wm.addView(bubble, bubbleLp);

        buildPanel();
    }

    private class BubbleTouch implements View.OnTouchListener {
        float sx, sy; int ox, oy; boolean moved; long down;
        final Runnable longPress = () -> { moved = true; analyze(true); };
        @Override public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getRawX(); sy = e.getRawY(); ox = bubbleLp.x; oy = bubbleLp.y; moved = false;
                    down = System.currentTimeMillis();
                    main.postDelayed(longPress, 600);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                    if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) {
                        main.removeCallbacks(longPress);
                        moved = true;
                        bubbleLp.x = ox + (int) dx; bubbleLp.y = oy + (int) dy;
                        wm.updateViewLayout(bubble, bubbleLp);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    main.removeCallbacks(longPress);
                    if (!moved) togglePanel();
                    return true;
            }
            return false;
        }
    }

    private void buildPanel() {
        panel = new LinearLayout(this) {
            // 뒤로가기 버튼으로 비서 창 닫기
            @Override public boolean dispatchKeyEvent(android.view.KeyEvent ev) {
                if (ev.getKeyCode() == android.view.KeyEvent.KEYCODE_BACK) {
                    if (ev.getAction() == android.view.KeyEvent.ACTION_UP) hidePanel();
                    return true;
                }
                return super.dispatchKeyEvent(ev);
            }
        };
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(C_BG);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), 0x9922D3EE);
        panel.setBackground(bg);

        // 상단: 제목 + 닫기
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText("J.A.R.V.I.S");
        t.setTextColor(0xFF22D3EE);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        t.setLetterSpacing(0.12f);
        top.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(0xFF7FA3B8);
        close.setTextSize(18);
        close.setPadding(dp(12), dp(4), dp(4), dp(4));
        close.setOnClickListener(v -> hidePanel());
        top.addView(close);
        panel.addView(top);

        // 모드 탭
        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(0, dp(8), 0, dp(8));
        String[][] modes = {{"auto", "자동"}, {"game", "게임"}, {"stock", "주식"}, {"paper", "논문"}};
        for (int i = 0; i < 4; i++) {
            final String key = modes[i][0];
            TextView tab = new TextView(this);
            tab.setText(modes[i][1]);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(0, dp(7), 0, dp(7));
            tab.setOnClickListener(v -> { mode = key; paintTabs(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.setMargins(dp(2), 0, dp(2), 0);
            tabs.addView(tab, lp);
            modeTabs[i] = tab;
            tab.setTag(key);
        }
        panel.addView(tabs);
        paintTabs();

        // 답변 영역
        ScrollView sc = new ScrollView(this);
        answer = new TextView(this);
        answer.setTextColor(0xFFE2F3FA);
        answer.setTextSize(14);
        answer.setLineSpacing(dp(3), 1f);
        answer.setText("화면 분석을 누르면 지금 화면을 보고 도와드릴게요.\n질문을 적고 [질문]을 누르면 화면 없이 답해요.");
        answer.setMovementMethod(LinkMovementMethod.getInstance());
        answer.setLinkTextColor(0xFF67E8F9);
        sc.addView(answer);
        panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));

        // 입력 + 버튼
        question = new EditText(this);
        question.setHint("궁금한 것 (선택)");
        question.setTextColor(0xFFE2F3FA);
        question.setHintTextColor(0xFF4A6577);
        question.setTextSize(14);
        question.setMaxLines(3);
        panel.addView(question);

        LinearLayout row = new LinearLayout(this);
        row.addView(pill("화면 분석", true, v -> analyze(true)), new LinearLayout.LayoutParams(0, dp(44), 1.4f));
        View gap = new View(this);
        row.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(pill("질문", false, v -> analyze(false)), new LinearLayout.LayoutParams(0, dp(44), 1));
        panel.addView(row);

        int screenH = getResources().getDisplayMetrics().heightPixels;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        panelLp = new WindowManager.LayoutParams(Math.min(screenW - dp(24), dp(460)), Math.min(dp(520), (int) (screenH * 0.7)),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.CENTER;
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
    }

    private Button pill(String s, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(primary ? 0xFF0A1420 : 0xFF22D3EE);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        if (primary) g.setColor(0xFF22D3EE); else { g.setColor(0x00000000); g.setStroke(dp(1), 0xFF22D3EE); }
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    private void paintTabs() {
        for (TextView tab : modeTabs) {
            boolean on = mode.equals(tab.getTag());
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(8));
            if (on) g.setColor(0x3322D3EE); else g.setColor(0x00000000);
            g.setStroke(dp(1), on ? 0xFF22D3EE : 0x3322D3EE);
            tab.setBackground(g);
            tab.setTextColor(on ? 0xFF22D3EE : 0xFF7FA3B8);
        }
    }

    private boolean panelShown() { return panel != null && panel.getParent() != null; }

    private void togglePanel() { if (panelShown()) hidePanel(); else showPanel(); }

    private void showPanel() {
        if (panelShown()) return;
        resizePanel();
        try { wm.addView(panel, panelLp); } catch (Exception ignored) { }
    }

    private void hidePanel() {
        if (!panelShown()) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        try {
            imm.hideSoftInputFromWindow(question.getWindowToken(), 0);
            wm.removeView(panel);
        } catch (Exception ignored) { }
    }

    // ================= AI 호출 =================
    private void analyze(boolean withScreen) {
        if (busy) return;
        final AiClient client = new AiClient(this);   // 누를 때마다 최신 설정(키·모델)을 다시 읽음
        String q = question.getText().toString();
        if (!withScreen && q.trim().isEmpty()) { showPanel(); answer.setText("질문을 먼저 적어주세요."); return; }
        if (!client.hasKey()) { showPanel(); answer.setText("저장된 API 키가 없어요.\n자비스 앱을 열어 키를 붙여넣고 [연결 테스트]를 눌러주세요."); return; }

        busy = true;
        final String curMode = mode;
        if (withScreen) {
            // 비서 창과 버튼을 숨겨야 실제 화면만 찍힘
            hidePanel();
            bubble.setVisibility(View.INVISIBLE);
        }
        main.postDelayed(() -> {
            exec.execute(() -> {
                try {
                    String grabbed = null;
                    if (withScreen) {
                        try { grabbed = grabScreen(); } catch (Throwable t) { grabbed = null; }
                    }
                    final String img = grabbed;
                    final String status;
                    if (!withScreen) status = "찾는 중…";
                    else if (img == null) status = "화면을 가져오지 못했어요. 화면을 한 번 움직인 뒤 다시 눌러주세요.\n(계속 이러면 자비스를 종료했다가 다시 시작해 주세요)";
                    else if (BLACK.equals(img)) status = "이 앱은 화면 캡처를 막고 있어서 화면이 검게 보여요. (증권·은행 앱에서 흔해요)\n종목명을 아래에 적고 [질문]을 눌러주세요.";
                    else status = "화면을 분석하는 중…";
                    main.post(() -> {
                        bubble.setVisibility(View.VISIBLE);
                        showPanel();
                        bubble.setText("…");
                        answer.setText(status);
                    });
                    if (withScreen && (img == null || BLACK.equals(img))) return;

                    AiClient.Result r = client.ask(curMode, q, img);
                    main.post(() -> answer.setText(render(r)));
                } catch (Throwable e) {
                    String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                    if (e instanceof java.io.IOException) msg = "인터넷 연결을 확인해 주세요.\n(" + msg + ")";
                    final String m = msg;
                    main.post(() -> answer.setText("⚠ " + m));
                } finally {
                    busy = false;   // 어떤 오류가 나도 다음 요청을 받을 수 있게
                    main.post(() -> { if (bubble != null) { bubble.setVisibility(View.VISIBLE); bubble.setText("J"); } });
                }
            });
        }, withScreen ? 350 : 0);
    }

    private CharSequence render(AiClient.Result r) {
        StringBuilder h = new StringBuilder(mdToHtml(r.text.isEmpty() ? "(답변 없음)" : r.text));
        if (!r.links.isEmpty()) {
            h.append("<br><br><font color='#7FA3B8'>관련 링크</font>");
            for (AiClient.Link l : r.links) {
                h.append("<br>• <a href=\"").append(Html.escapeHtml(l.url)).append("\">")
                        .append(Html.escapeHtml(l.title.isEmpty() ? l.url : l.title)).append("</a>");
            }
        }
        if (!r.usedModel.isEmpty()) h.append("<br><br><small><font color='#4A6577'>").append(Html.escapeHtml(r.usedModel)).append("</font></small>");
        Spanned sp = Html.fromHtml(h.toString(), Html.FROM_HTML_MODE_LEGACY);
        // 서비스에서도 링크가 열리도록 URLSpan 교체
        SpannableStringBuilder sb = new SpannableStringBuilder(sp);
        for (URLSpan u : sb.getSpans(0, sb.length(), URLSpan.class)) {
            int s = sb.getSpanStart(u), e = sb.getSpanEnd(u);
            final String url = u.getURL();
            sb.removeSpan(u);
            sb.setSpan(new ClickableSpan() {
                @Override public void onClick(View w) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        hidePanel();
                    } catch (Exception ignored) { }
                }
            }, s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return sb;
    }

    private static String mdToHtml(String md) {
        String s = Html.escapeHtml(md);
        s = s.replaceAll("\\*\\*(.+?)\\*\\*", "<b>$1</b>");
        s = s.replaceAll("(?m)^#+\\s*", "");
        s = s.replaceAll("(?m)^[*-]\\s+", "• ");
        return s.replace("\n", "<br>");
    }

    // ================= 알림 / 종료 =================
    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "자비스 실행 중", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, AssistantService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("자비스가 대기 중이에요")
                .setContentText("파란 원을 눌러 도움을 받으세요")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "종료", stop).build())
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (panelShown()) wm.removeView(panel); } catch (Exception ignored) { }
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) { }
        bubble = null;
        if (vdisplay != null) vdisplay.release();
        if (projection != null) projection.stop();
        projection = null;
        synchronized (imgLock) { if (latest != null) { latest.close(); latest = null; } }
        if (reader != null) reader.close();
        if (imgThread != null) imgThread.quitSafely();
        exec.shutdownNow();
        super.onDestroy();
    }
}
