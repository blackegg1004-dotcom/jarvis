package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    static final String PREFS = "jarvis";
    static final int C_BG = 0xFF0A1420;
    static final int C_CARD = 0xFF101F30;
    static final int C_CYAN = 0xFF22D3EE;
    static final int C_TEXT = 0xFFE2F3FA;
    static final int C_MUTED = 0xFF7FA3B8;

    private static final int REQ_CAPTURE = 1001;

    private RadioGroup providerGroup;
    private EditText keyInput, modelInput;
    private TextView statusText, keyStatus, testResult;
    private boolean loading = false;

    /** 글자가 바뀔 때만 알려주는 간단한 TextWatcher */
    static class SimpleWatcher implements android.text.TextWatcher {
        private final Runnable r;
        SimpleWatcher(Runnable r) { this.r = r; }
        @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
        @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
        @Override public void afterTextChanged(android.text.Editable s) { r.run(); }
    }

    private void updateKeyStatus() {
        String k = AiClient.cleanKey(keyInput.getText().toString());
        if (k.isEmpty()) {
            keyStatus.setText("○ 저장된 키 없음");
            keyStatus.setTextColor(0xFFF59E0B);
        } else {
            keyStatus.setText("● 저장됨: " + AiClient.maskKey(k));
            keyStatus.setTextColor(C_CYAN);
        }
    }

    private void runTest() {
        save();
        testResult.setTextColor(C_MUTED);
        testResult.setText("확인 중… (10초 정도 걸려요)");
        new Thread(() -> {
            String res = new AiClient(this).test();
            runOnUiThread(() -> {
                testResult.setTextColor(res.contains("❌") || res.contains("⚠") ? 0xFFF87171 : C_TEXT);
                testResult.setText(res);
            });
        }).start();
    }

    static String defaultModel(String provider) {
        return "claude".equals(provider) ? "claude-sonnet-5-5" : "gemini-3.8-flash";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(C_BG);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(C_BG);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, dp(16), pad, pad);
        scroll.addView(root);
        // 안드로이드 15+는 화면이 상태바·키보드 밑까지 그려지므로 그만큼 여백을 줌
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });

        TextView title = new TextView(this);
        title.setText("J.A.R.V.I.S");
        title.setTextColor(C_CYAN);
        title.setTextSize(30);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setLetterSpacing(0.15f);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("화면을 보고 게임·주식·논문을 도와주는 비서  ·  v2.1");
        sub.setTextColor(C_MUTED);
        sub.setPadding(0, dp(4), 0, dp(20));
        root.addView(sub);

        // ---- AI 설정 카드 ----
        LinearLayout card = card(root, "AI 설정");

        providerGroup = new RadioGroup(this);
        providerGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton rGemini = radio("Gemini (무료 한도)", 1);
        RadioButton rClaude = radio("Claude", 2);
        providerGroup.addView(rGemini);
        providerGroup.addView(rClaude);
        String provider = p.getString("provider", "gemini");
        providerGroup.check("claude".equals(provider) ? 2 : 1);
        card.addView(providerGroup);

        card.addView(label("API 키 (붙여넣으면 자동 저장)"));
        keyInput = input("여기에 API 키 붙여넣기");
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        keyInput.setText(p.getString("key_" + provider, ""));
        card.addView(keyInput);

        keyStatus = new TextView(this);
        keyStatus.setTextSize(12);
        keyStatus.setPadding(0, dp(4), 0, 0);
        card.addView(keyStatus);

        card.addView(label("모델 (비워두면 자동 선택 · 권장)"));
        modelInput = input("자동 선택");
        modelInput.setText(p.getString("model_" + provider, ""));
        card.addView(modelInput);

        providerGroup.setOnCheckedChangeListener((g, id) -> {
            String now = id == 2 ? "claude" : "gemini";
            loading = true;
            keyInput.setText(p.getString("key_" + now, ""));
            modelInput.setText(p.getString("model_" + now, ""));
            loading = false;
            p.edit().putString("provider", now).apply();
            testResult.setText("");
            updateKeyStatus();
        });

        // 입력할 때마다 바로 저장 (저장 버튼을 안 눌러도 키가 사라지지 않게)
        keyInput.addTextChangedListener(new SimpleWatcher(() -> {
            if (loading) return;
            String prov = currentProvider();
            String k = AiClient.cleanKey(keyInput.getText().toString());
            SharedPreferences.Editor e = p.edit().putString("provider", prov).putString("key_" + prov, k);
            if (prov.equals("gemini")) e.remove("gemini_models").remove("gemini_ok_model"); // 새 키면 모델 다시 찾기
            e.apply();
            updateKeyStatus();
        }));
        modelInput.addTextChangedListener(new SimpleWatcher(() -> {
            if (loading) return;
            p.edit().putString("model_" + currentProvider(), modelInput.getText().toString().trim()).apply();
        }));

        TextView keyHelp = new TextView(this);
        keyHelp.setText("Gemini 키 받기: aistudio.google.com/apikey\nClaude 키 받기: console.anthropic.com");
        keyHelp.setTextColor(C_MUTED);
        keyHelp.setTextSize(12);
        keyHelp.setPadding(0, dp(8), 0, dp(8));
        keyHelp.setOnClickListener(v -> openUrl(currentProvider().equals("claude")
                ? "https://console.anthropic.com/settings/keys" : "https://aistudio.google.com/apikey"));
        card.addView(keyHelp);

        card.addView(button("연결 테스트", v -> runTest(), false));
        testResult = new TextView(this);
        testResult.setTextColor(C_TEXT);
        testResult.setTextSize(13);
        testResult.setLineSpacing(dp(2), 1f);
        testResult.setPadding(0, dp(8), 0, 0);
        testResult.setTextIsSelectable(true);
        card.addView(testResult);
        updateKeyStatus();

        // ---- 권한 카드 ----
        LinearLayout perm = card(root, "권한");
        perm.addView(button("① 다른 앱 위에 표시 허용", v -> openOverlaySettings(), false));
        perm.addView(button("② 알림 허용", v -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
            else toast("이 기기는 따로 필요 없어요");
        }, false));

        // ---- 실행 카드 ----
        LinearLayout run = card(root, "실행");
        statusText = new TextView(this);
        statusText.setTextColor(C_MUTED);
        statusText.setPadding(0, 0, 0, dp(8));
        run.addView(statusText);
        run.addView(button("자비스 시작", v -> startAssistant(), true));
        run.addView(button("자비스 종료", v -> {
            Intent i = new Intent(this, AssistantService.class).setAction(AssistantService.ACTION_STOP);
            startService(i);
            refreshStatus();
        }, false));

        TextView how = new TextView(this);
        how.setText("사용법\n• 시작하면 화면 가장자리에 파란 원이 떠요\n• 원을 누르면 비서 창이 열려요\n• [화면 분석]: 지금 화면을 보고 도와줘요\n• [질문]: 화면 없이 글로만 물어봐요\n• 모드: 자동 / 게임 / 주식 / 논문\n• 원을 길게 누르면 바로 화면 분석\n• 원을 끌어서 위치를 옮길 수 있어요");
        how.setTextColor(C_MUTED);
        how.setTextSize(13);
        how.setLineSpacing(dp(3), 1f);
        how.setPadding(0, dp(16), 0, 0);
        root.addView(how);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        statusText.postDelayed(() -> {
            boolean overlay = Settings.canDrawOverlays(this);
            String s = (AssistantService.running ? "● 실행 중" : "○ 꺼져 있음")
                    + (overlay ? "" : "  ·  ① 권한이 필요해요");
            statusText.setText(s);
            statusText.setTextColor(AssistantService.running ? C_CYAN : C_MUTED);
        }, 300);
    }

    private String currentProvider() {
        return providerGroup.getCheckedRadioButtonId() == 2 ? "claude" : "gemini";
    }

    private void save() {
        String prov = currentProvider();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("provider", prov)
                .putString("key_" + prov, AiClient.cleanKey(keyInput.getText().toString()))
                .putString("model_" + prov, modelInput.getText().toString().trim())
                .commit();
    }

    private void startAssistant() {
        save();
        if (AiClient.cleanKey(keyInput.getText().toString()).isEmpty()) { toast("API 키를 먼저 넣어주세요"); return; }
        if (!Settings.canDrawOverlays(this)) { toast("① '다른 앱 위에 표시'를 먼저 허용해주세요"); openOverlaySettings(); return; }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        Intent capture;
        if (Build.VERSION.SDK_INT >= 34) {
            // 안드로이드 14+: '앱 하나만 공유'를 고르면 다른 앱 화면이 안 보이므로 전체 화면 공유로 고정
            capture = mpm.createScreenCaptureIntent(android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay());
        } else {
            capture = mpm.createScreenCaptureIntent();
        }
        startActivityForResult(capture, REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) { toast("화면 공유를 허용해야 화면을 볼 수 있어요"); return; }
        Intent i = new Intent(this, AssistantService.class)
                .setAction(AssistantService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data);
        startForegroundService(i);
        toast("자비스가 시작됐어요");
        moveTaskToBack(true);
    }

    private void openOverlaySettings() {
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
    }

    private void openUrl(String u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception ignored) { }
    }

    // ---- 작은 UI 도우미 ----
    int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(C_CARD);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0x3322D3EE);
        c.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(14);
        parent.addView(c, lp);
        TextView h = new TextView(this);
        h.setText(heading);
        h.setTextColor(C_CYAN);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(0, 0, 0, dp(8));
        c.addView(h);
        return c;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(C_MUTED);
        t.setTextSize(12);
        t.setPadding(0, dp(10), 0, dp(2));
        return t;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextColor(C_TEXT);
        e.setHintTextColor(0xFF4A6577);
        return e;
    }

    private RadioButton radio(String s, int id) {
        RadioButton r = new RadioButton(this);
        r.setId(id);
        r.setText(s);
        r.setTextColor(C_TEXT);
        r.setButtonTintList(android.content.res.ColorStateList.valueOf(C_CYAN));
        r.setPadding(0, 0, dp(16), 0);
        return r;
    }

    private Button button(String s, View.OnClickListener l, boolean primary) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(primary ? C_BG : C_CYAN);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(10));
        if (primary) bg.setColor(C_CYAN); else { bg.setColor(Color.TRANSPARENT); bg.setStroke(dp(1), C_CYAN); }
        b.setBackground(bg);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }
}
