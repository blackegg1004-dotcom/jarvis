package com.jarvis.assistant;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Gemini / Claude 호출과 논문 검색(Semantic Scholar)을 담당. 네트워크 메서드는 모두 백그라운드 스레드에서 호출할 것. */
public class AiClient {

    public static class Link {
        public final String title, url;
        Link(String t, String u) { title = t; url = u; }
    }

    public static class Result {
        public String text = "";
        public String usedModel = "";
        public final List<Link> links = new ArrayList<>();
    }

    /** HTTP 오류를 코드와 함께 들고 다니기 위한 예외 */
    public static class ApiException extends Exception {
        public final int code;
        ApiException(int code, String msg) { super(msg); this.code = code; }
    }

    static String GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/";
    static String CLAUDE_URL = "https://api.anthropic.com/v1/messages";
    static String PAPER_URL = "https://api.semanticscholar.org/graph/v1/paper/search";

    private final Context ctx;
    private final SharedPreferences prefs;
    private final String provider, key, userModel;

    /** 설정에서 현재 공급자·키·모델을 읽어서 만든다 */
    public AiClient(Context c) {
        ctx = c.getApplicationContext();
        prefs = ctx.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        provider = prefs.getString("provider", "gemini");
        key = cleanKey(prefs.getString("key_" + provider, ""));
        userModel = prefs.getString("model_" + provider, "").trim();
    }

    public boolean hasKey() { return !key.isEmpty(); }
    public String provider() { return provider; }

    /** 붙여넣을 때 섞여 들어오는 공백·줄바꿈·따옴표 제거 */
    static String cleanKey(String k) {
        if (k == null) return "";
        return k.replaceAll("[\\s\"'`]", "");
    }

    static String maskKey(String k) {
        k = cleanKey(k);
        if (k.isEmpty()) return "";
        if (k.length() <= 10) return k.charAt(0) + "…";
        return k.substring(0, 6) + "…" + k.substring(k.length() - 4) + " (" + k.length() + "자)";
    }

    // ================= 프롬프트 =================
    static final String SYSTEM = "너는 사용자의 휴대폰 화면을 함께 보는 개인 비서 '자비스'다. 한국어로, 휴대폰 화면에서 읽기 좋게 짧고 핵심만 답한다. "
            + "목록은 '• '로 시작하고, 마크다운 표나 제목(#)은 쓰지 않는다. 확실하지 않은 정보는 추측이라고 밝힌다. "
            + "최신 정보가 필요하면 웹 검색을 사용한다.";

    static String modePrompt(String mode, boolean hasImage) {
        String screen = hasImage ? "첨부한 이미지는 지금 사용자의 휴대폰 화면이다. " : "";
        switch (mode) {
            case "game":
                return screen + "사용자는 게임 중이다. 어떤 게임의 어떤 상황인지 파악하고, 지금 바로 써먹을 수 있는 공략·팁·다음 행동을 알려줘. "
                        + "퀘스트, 보스, 아이템, 퍼즐이 보이면 검색해서 구체적인 해법을 알려줘.";
            case "stock":
                return screen + "사용자는 주식/투자 정보를 보고 있다. 화면의 종목(회사명·티커)을 파악하고, 웹 검색으로 최신 주가 흐름, 최근 뉴스, "
                        + "핵심 지표(시가총액, PER 등), 주목할 이슈를 정리해줘. 매수·매도 권유는 하지 말고 판단에 필요한 사실만 전달해.";
            case "paper":
                return screen + "사용자는 논문이나 학술 자료를 찾고 있다. 주제를 파악하고 웹 검색으로 관련 핵심 논문·자료를 찾아 각각 한 줄 요약과 함께 알려줘. "
                        + "답변 맨 마지막 줄에 학술 검색용 영어 키워드를 'QUERY: 키워드' 형식으로 한 줄 적어줘.";
            default:
                return screen + "사용자가 무엇을 하고 있는지(게임, 주식, 공부·논문, 쇼핑, 기타) 먼저 한 줄로 판단하고, 그 상황에서 가장 도움이 되는 정보를 찾아줘. "
                        + "게임이면 공략, 주식이면 종목 뉴스와 지표, 논문·공부면 관련 자료를 검색해서 알려줘. "
                        + "논문·학술 주제라면 답변 맨 마지막 줄에 'QUERY: 영어 키워드'를 한 줄 적어줘.";
        }
    }

    // ================= 공개 메서드 =================
    public Result ask(String mode, String userText, String imageB64) throws Exception {
        if (key.isEmpty()) throw new Exception("API 키가 저장돼 있지 않아요. 자비스 앱에서 키를 넣고 [연결 테스트]를 눌러주세요.");
        String prompt = modePrompt(mode, imageB64 != null);
        if (userText != null && !userText.trim().isEmpty()) prompt += "\n\n사용자 질문: " + userText.trim();
        Result r = "claude".equals(provider) ? claude(prompt, imageB64, true) : geminiWithFallback(prompt, imageB64);

        // 논문 키워드가 있으면 Semantic Scholar에서 실제 논문 링크를 붙인다
        String q = extractQuery(r);
        if (q != null) {
            try { r.links.addAll(0, searchPapers(q)); } catch (Exception ignored) { }
        }
        return r;
    }

    /** 키가 맞는지, 어떤 모델이 실제로 되는지 확인하고 결과를 사람이 읽을 문장으로 돌려준다 */
    public String test() {
        if (key.isEmpty()) return "❌ 저장된 키가 없어요. 키를 붙여넣어 주세요.";
        StringBuilder out = new StringBuilder();
        out.append("키: ").append(maskKey(key)).append('\n');
        try {
            if ("claude".equals(provider)) {
                Result r = claude("'연결 성공'이라고만 답해.", null, false);
                out.append("✅ Claude 연결 성공\n모델: ").append(r.usedModel);
                return out.toString();
            }
            // 1) 키 확인 + 이 키로 쓸 수 있는 모델 목록
            List<String> models = refreshGeminiModels();
            out.append("✅ 키 확인 완료 (사용 가능 모델 ").append(models.size()).append("개)\n");
            if (models.isEmpty() && userModel.isEmpty()) {
                out.append("⚠ 이 키로 쓸 수 있는 Gemini 모델이 없어요.");
                return out.toString();
            }
            // 2) 실제로 짧게 한 번 물어보기 (한도가 남은 모델을 찾음)
            Result r = geminiWithFallback("'연결 성공'이라고만 답해.", null, false);
            out.append("✅ 답변 성공 · 모델: ").append(r.usedModel);
        } catch (ApiException e) {
            out.append("❌ ").append(e.getMessage());
        } catch (Exception e) {
            out.append("❌ ").append(e.getMessage() == null ? "인터넷 연결을 확인해 주세요." : e.getMessage());
        }
        return out.toString();
    }

    private static String extractQuery(Result r) {
        int i = r.text.lastIndexOf("QUERY:");
        if (i < 0) return null;
        String q = r.text.substring(i + 6).split("\n")[0].trim();
        r.text = r.text.substring(0, i).trim();
        return q.isEmpty() ? null : q;
    }

    // ================= Gemini =================
    /** 이 키로 generateContent가 가능한 flash 계열 모델을 좋은 순서로 받아와 저장 */
    List<String> refreshGeminiModels() throws Exception {
        Map<String, String> h = new LinkedHashMap<>();
        h.put("x-goog-api-key", key);
        JSONObject res = request("GET", GEMINI_BASE + "models?pageSize=1000", h, null);
        JSONArray arr = res.optJSONArray("models");
        List<String> names = new ArrayList<>();
        if (arr != null) for (int i = 0; i < arr.length(); i++) {
            JSONObject m = arr.getJSONObject(i);
            String name = m.optString("name").replace("models/", "");
            JSONArray methods = m.optJSONArray("supportedGenerationMethods");
            boolean gen = methods == null || methods.toString().contains("generateContent");
            String n = name.toLowerCase();
            if (!gen || !n.startsWith("gemini") || !n.contains("flash")) continue;
            if (n.contains("image") || n.contains("tts") || n.contains("live") || n.contains("audio")
                    || n.contains("embedding") || n.contains("exp")) continue;
            names.add(name);
        }
        Collections.sort(names, (a, b) -> Double.compare(score(b), score(a)));
        if (names.size() > 6) names = new ArrayList<>(names.subList(0, 6));
        prefs.edit().putString("gemini_models", String.join(",", names)).apply();
        return names;
    }

    /** 버전이 높을수록, 정식(비 preview)일수록, lite가 아닐수록 우선 */
    private static double score(String name) {
        Matcher m = Pattern.compile("gemini-(\\d+(?:\\.\\d+)?)").matcher(name);
        double v = m.find() ? Double.parseDouble(m.group(1)) : 0;
        double s = v * 10;
        if (name.contains("lite")) s -= 3;
        if (name.contains("preview")) s -= 2;
        if (name.matches(".*-\\d{3}$") || name.contains("latest")) s -= 0.5;
        return s;
    }

    /** 시도할 모델 순서: 사용자가 직접 적은 모델 → 마지막으로 성공한 모델 → 자동으로 찾은 목록 → 기본값 */
    private List<String> geminiCandidates() {
        List<String> c = new ArrayList<>();
        addUnique(c, userModel);
        addUnique(c, prefs.getString("gemini_ok_model", ""));
        for (String s : prefs.getString("gemini_models", "").split(",")) addUnique(c, s.trim());
        addUnique(c, MainActivity.defaultModel("gemini"));
        addUnique(c, "gemini-3.5-flash");
        addUnique(c, "gemini-3.5-flash-lite");
        return c;
    }

    private static void addUnique(List<String> list, String s) {
        if (s != null && !s.isEmpty() && !list.contains(s)) list.add(s);
    }

    private Result geminiWithFallback(String prompt, String img) throws Exception {
        return geminiWithFallback(prompt, img, true);
    }

    private Result geminiWithFallback(String prompt, String img, boolean wantSearch) throws Exception {
        if (prefs.getString("gemini_models", "").isEmpty()) {
            try { refreshGeminiModels(); } catch (ApiException e) { if (e.code == 400 || e.code == 401 || e.code == 403) throw e; }
            catch (Exception ignored) { }
        }
        ApiException last = null;
        boolean searchBlocked = false;
        int attempts = 0;
        for (String model : geminiCandidates()) {
            if (attempts >= 6) break;   // 한도가 다 찬 상태에서 요청을 끝없이 낭비하지 않게
            attempts++;
            if (wantSearch && !searchBlocked) {
                try {
                    Result r = gemini(model, prompt, img, true);
                    prefs.edit().putString("gemini_ok_model", model).apply();
                    return r;
                } catch (ApiException e) {
                    last = e;
                    if (isKeyProblem(e)) throw e;
                    if (e.code == 404) continue;              // 없는 모델 → 다음 모델
                    searchBlocked = (e.code == 429 || e.code == 400 || e.code == 403); // 검색 한도 문제일 수 있음 → 검색 없이 재시도
                }
            }
            try {
                Result r = gemini(model, prompt, img, false);
                if (wantSearch) r.text += "\n\n(웹 검색 한도가 없어 검색 없이 답했어요)";
                prefs.edit().putString("gemini_ok_model", model).apply();
                return r;
            } catch (ApiException e) {
                last = e;
                if (isKeyProblem(e)) throw e;
                // 404(없는 모델), 429(이 모델 한도 초과), 5xx → 다음 모델로
            }
        }
        if (last != null) throw last;
        throw new Exception("사용할 수 있는 모델을 찾지 못했어요.");
    }

    private static boolean isKeyProblem(ApiException e) {
        if (e.code == 401) return true;
        String m = String.valueOf(e.getMessage());
        return m.contains("API key") || m.contains("API_KEY") || m.contains("ACCESS_TOKEN") || m.contains("leaked");
    }

    private Result gemini(String model, String prompt, String img, boolean useSearch) throws Exception {
        JSONObject body = new JSONObject();
        body.put("system_instruction", new JSONObject().put("parts",
                new JSONArray().put(new JSONObject().put("text", SYSTEM))));
        JSONArray parts = new JSONArray();
        if (img != null) parts.put(new JSONObject().put("inline_data",
                new JSONObject().put("mime_type", "image/jpeg").put("data", img)));
        parts.put(new JSONObject().put("text", prompt));
        body.put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", parts)));
        if (useSearch) body.put("tools", new JSONArray().put(new JSONObject().put("google_search", new JSONObject())));

        Map<String, String> h = new LinkedHashMap<>();
        h.put("x-goog-api-key", key);
        JSONObject res = request("POST", GEMINI_BASE + "models/" + model + ":generateContent", h, body);

        Result r = new Result();
        r.usedModel = model;
        JSONArray cands = res.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) {
            JSONObject fb = res.optJSONObject("promptFeedback");
            throw new Exception("답변이 비어 있어요" + (fb != null ? " (" + fb.optString("blockReason") + ")" : ""));
        }
        JSONObject c0 = cands.getJSONObject(0);
        JSONObject content = c0.optJSONObject("content");
        StringBuilder sb = new StringBuilder();
        if (content != null) {
            JSONArray ps = content.optJSONArray("parts");
            if (ps != null) for (int i = 0; i < ps.length(); i++) {
                JSONObject p = ps.getJSONObject(i);
                if (p.optBoolean("thought", false)) continue;
                sb.append(p.optString("text"));
            }
        }
        r.text = sb.toString().trim();
        JSONObject gm = c0.optJSONObject("groundingMetadata");
        if (gm != null) {
            JSONArray chunks = gm.optJSONArray("groundingChunks");
            if (chunks != null) for (int i = 0; i < chunks.length() && r.links.size() < 6; i++) {
                JSONObject w = chunks.getJSONObject(i).optJSONObject("web");
                if (w != null) addLink(r, w.optString("title", "출처"), w.optString("uri"));
            }
        }
        return r;
    }

    // ================= Claude =================
    private Result claude(String prompt, String img, boolean useSearch) throws Exception {
        String model = userModel.isEmpty() ? MainActivity.defaultModel("claude") : userModel;
        JSONArray content = new JSONArray();
        if (img != null) content.put(new JSONObject().put("type", "image").put("source",
                new JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", img)));
        content.put(new JSONObject().put("type", "text").put("text", prompt));
        JSONArray messages = new JSONArray().put(new JSONObject().put("role", "user").put("content", content));

        Map<String, String> h = new LinkedHashMap<>();
        h.put("x-api-key", key);
        h.put("anthropic-version", "2023-06-01");

        Result r = new Result();
        r.usedModel = model;
        StringBuilder sb = new StringBuilder();
        for (int turn = 0; turn < 3; turn++) {
            JSONObject body = new JSONObject();
            body.put("model", model);
            body.put("max_tokens", 1500);
            body.put("system", SYSTEM);
            body.put("messages", messages);
            if (useSearch) body.put("tools", new JSONArray().put(new JSONObject()
                    .put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)));
            JSONObject res = request("POST", CLAUDE_URL, h, body);

            JSONArray blocks = res.optJSONArray("content");
            if (blocks != null) for (int i = 0; i < blocks.length(); i++) {
                JSONObject b = blocks.getJSONObject(i);
                if (!"text".equals(b.optString("type"))) continue;
                sb.append(b.optString("text"));
                JSONArray cits = b.optJSONArray("citations");
                if (cits != null) for (int j = 0; j < cits.length() && r.links.size() < 6; j++) {
                    JSONObject ct = cits.getJSONObject(j);
                    addLink(r, ct.optString("title", "출처"), ct.optString("url"));
                }
            }
            if (!"pause_turn".equals(res.optString("stop_reason")) || blocks == null) break;
            // 서버 검색이 길어져 중간에 멈춘 경우 이어서 요청
            messages.put(new JSONObject().put("role", "assistant").put("content", blocks));
        }
        r.text = sb.toString().trim();
        return r;
    }

    // ================= 논문 검색 (Semantic Scholar, 키 불필요) =================
    private List<Link> searchPapers(String q) throws Exception {
        String url = PAPER_URL + "?limit=5&fields=title,year,url,citationCount&query="
                + URLEncoder.encode(q, "UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        List<Link> out = new ArrayList<>();
        if (c.getResponseCode() != 200) return out;
        JSONArray data = new JSONObject(read(c.getInputStream())).optJSONArray("data");
        if (data == null) return out;
        for (int i = 0; i < data.length(); i++) {
            JSONObject p = data.getJSONObject(i);
            String t = "📄 " + p.optString("title") + (p.has("year") && !p.isNull("year") ? " (" + p.optInt("year") + ")" : "")
                    + " · 인용 " + p.optInt("citationCount");
            out.add(new Link(t, p.optString("url")));
        }
        return out;
    }

    // ================= 공통 =================
    private static void addLink(Result r, String title, String url) {
        if (url == null || url.isEmpty()) return;
        for (Link l : r.links) if (l.url.equals(url)) return;
        r.links.add(new Link(title, url));
    }

    private static JSONObject request(String method, String url, Map<String, String> headers, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(20000);
        c.setReadTimeout(120000);
        for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("content-type", "application/json");
            try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        }
        int code = c.getResponseCode();
        String text = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
        if (code >= 400) {
            String msg = text;
            try {
                JSONObject err = new JSONObject(text).optJSONObject("error");
                if (err != null) msg = err.optString("message", text);
            } catch (Exception ignored) { }
            if (msg.length() > 300) msg = msg.substring(0, 300) + "…";
            throw new ApiException(code, friendly(code, msg) + "\n(" + code + ") " + msg);
        }
        return new JSONObject(text);
    }

    private static String friendly(int code, String msg) {
        if (code == 401 || msg.contains("API key not valid") || msg.contains("API_KEY_INVALID"))
            return "API 키가 올바르지 않거나 차단됐어요. 새 키를 만들어 다시 붙여넣어 주세요.";
        if (code == 403) return "이 키로는 권한이 없어요. 키가 차단됐거나 Gemini API 사용이 막혀 있을 수 있어요.";
        if (code == 400) return "요청 오류예요. 모델 칸을 비워서 자동 선택을 써보세요.";
        if (code == 404) return "모델을 찾을 수 없어요. 모델 칸을 비워서 자동 선택을 써보세요.";
        if (code == 429) return "모든 모델의 사용 한도를 넘었어요. 잠시(또는 내일) 후 다시 시도해 주세요.";
        if (code >= 500) return "AI 서버가 잠시 불안정해요.";
        return "오류가 났어요.";
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
