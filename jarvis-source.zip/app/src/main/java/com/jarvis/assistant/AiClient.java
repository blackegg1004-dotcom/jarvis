package com.jarvis.assistant;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Gemini / Claude 호출과 논문 검색(Semantic Scholar)을 담당. 모두 백그라운드 스레드에서 호출할 것. */
public class AiClient {

    public static class Link {
        public final String title, url;
        Link(String t, String u) { title = t; url = u; }
    }

    public static class Result {
        public String text = "";
        public final List<Link> links = new ArrayList<>();
    }

    private final String provider, key, model;

    public AiClient(String provider, String key, String model) {
        this.provider = provider;
        this.key = key;
        this.model = (model == null || model.isEmpty()) ? MainActivity.defaultModel(provider) : model;
    }

    static final String SYSTEM = "너는 사용자의 휴대폰 화면을 함께 보는 개인 비서 '자비스'다. 한국어로, 휴대폰 화면에서 읽기 좋게 짧고 핵심만 답한다. "
            + "목록은 '• '로 시작하고, 마크다운 표나 제목(#)은 쓰지 않는다. 확실하지 않은 정보는 추측이라고 밝힌다. "
            + "최신 정보가 필요하면 웹 검색을 사용한다.";

    static String modePrompt(String mode, boolean hasImage) {
        String screen = hasImage ? "첨부한 이미지는 지금 사용자의 휴대폰 화면이다. " : "";
        switch (mode) {
            case "game":
                return screen + "사용자는 게임 중이다. 어떤 게임의 어떤 상황인지 파악하고, 지금 바로 써먹을 수 있는 공략·팁·다음 행동을 알려줘. "
                        + "퀘스트, 보스, 아이템, 퍼즐이 보이면 검색해서 구체적인 해법을 알려줘.";
            case "stock":
                return screen + "사용자는 주식/투자 정보를 보고 있다. 화면의 종목(회사명·티커)을 파악하고, 웹 검색으로 최신 주가 흐름, 최근 뉴스, "
                        + "핵심 지표(시가총액, PER 등), 주목할 이슈를 정리해줘. 매수·매도 권유는 하지 말고 판단에 필요한 사실만 전달해.";
            case "paper":
                return screen + "사용자는 논문이나 학술 자료를 찾고 있다. 주제를 파악하고 웹 검색으로 관련 핵심 논문·자료를 찾아 각각 한 줄 요약과 함께 알려줘. "
                        + "답변 맨 마지막 줄에 학술 검색용 영어 키워드를 'QUERY: 키워드' 형식으로 한 줄 적어줘.";
            default:
                return screen + "사용자가 무엇을 하고 있는지(게임, 주식, 공부·논문, 쇼핑, 기타) 먼저 한 줄로 판단하고, 그 상황에서 가장 도움이 되는 정보를 찾아줘. "
                        + "게임이면 공략, 주식이면 종목 뉴스와 지표, 논문·공부면 관련 자료를 검색해서 알려줘. "
                        + "논문·학술 주제라면 답변 맨 마지막 줄에 'QUERY: 영어 키워드'를 한 줄 적어줘.";
        }
    }

    public Result ask(String mode, String userText, String imageB64) throws Exception {
        String prompt = modePrompt(mode, imageB64 != null);
        if (userText != null && !userText.trim().isEmpty()) prompt += "\n\n사용자 질문: " + userText.trim();
        Result r = "claude".equals(provider) ? claude(prompt, imageB64) : gemini(prompt, imageB64);

        // 논문 키워드가 있으면 Semantic Scholar에서 실제 논문 링크를 붙인다
        String q = extractQuery(r);
        if (q != null) {
            try { r.links.addAll(0, searchPapers(q)); } catch (Exception ignored) { }
        }
        return r;
    }

    private static String extractQuery(Result r) {
        int i = r.text.lastIndexOf("QUERY:");
        if (i < 0) return null;
        String q = r.text.substring(i + 6).split("\n")[0].trim();
        r.text = r.text.substring(0, i).trim();
        return q.isEmpty() ? null : q;
    }

    // ---------------- Gemini ----------------
    private Result gemini(String prompt, String img) throws Exception {
        JSONObject body = new JSONObject();
        body.put("system_instruction", new JSONObject().put("parts",
                new JSONArray().put(new JSONObject().put("text", SYSTEM))));
        JSONArray parts = new JSONArray();
        if (img != null) parts.put(new JSONObject().put("inline_data",
                new JSONObject().put("mime_type", "image/jpeg").put("data", img)));
        parts.put(new JSONObject().put("text", prompt));
        body.put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", parts)));
        body.put("tools", new JSONArray().put(new JSONObject().put("google_search", new JSONObject())));

        String url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent";
        Map<String, String> h = new LinkedHashMap<>();
        h.put("x-goog-api-key", key);
        JSONObject res = post(url, h, body);

        Result r = new Result();
        JSONArray cands = res.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) {
            JSONObject fb = res.optJSONObject("promptFeedback");
            throw new Exception("답변이 비어 있어요" + (fb != null ? " (" + fb.optString("blockReason") + ")" : ""));
        }
        JSONObject c0 = cands.getJSONObject(0);
        JSONObject content = c0.optJSONObject("content");
        StringBuilder sb = new StringBuilder();
        if (content != null) {
            JSONArray ps = content.optJSONArray("parts");
            if (ps != null) for (int i = 0; i < ps.length(); i++) sb.append(ps.getJSONObject(i).optString("text"));
        }
        r.text = sb.toString().trim();
        JSONObject gm = c0.optJSONObject("groundingMetadata");
        if (gm != null) {
            JSONArray chunks = gm.optJSONArray("groundingChunks");
            if (chunks != null) for (int i = 0; i < chunks.length() && r.links.size() < 6; i++) {
                JSONObject w = chunks.getJSONObject(i).optJSONObject("web");
                if (w != null) addLink(r, w.optString("title", "출처"), w.optString("uri"));
            }
        }
        return r;
    }

    // ---------------- Claude ----------------
    private Result claude(String prompt, String img) throws Exception {
        JSONArray content = new JSONArray();
        if (img != null) content.put(new JSONObject().put("type", "image").put("source",
                new JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", img)));
        content.put(new JSONObject().put("type", "text").put("text", prompt));
        JSONArray messages = new JSONArray().put(new JSONObject().put("role", "user").put("content", content));

        Map<String, String> h = new LinkedHashMap<>();
        h.put("x-api-key", key);
        h.put("anthropic-version", "2023-06-01");

        Result r = new Result();
        StringBuilder sb = new StringBuilder();
        for (int turn = 0; turn < 3; turn++) {
            JSONObject body = new JSONObject();
            body.put("model", model);
            body.put("max_tokens", 1500);
            body.put("system", SYSTEM);
            body.put("messages", messages);
            body.put("tools", new JSONArray().put(new JSONObject()
                    .put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)));
            JSONObject res = post("https://api.anthropic.com/v1/messages", h, body);

            JSONArray blocks = res.optJSONArray("content");
            if (blocks != null) for (int i = 0; i < blocks.length(); i++) {
                JSONObject b = blocks.getJSONObject(i);
                if (!"text".equals(b.optString("type"))) continue;
                sb.append(b.optString("text"));
                JSONArray cits = b.optJSONArray("citations");
                if (cits != null) for (int j = 0; j < cits.length() && r.links.size() < 6; j++) {
                    JSONObject ct = cits.getJSONObject(j);
                    addLink(r, ct.optString("title", "출처"), ct.optString("url"));
                }
            }
            if (!"pause_turn".equals(res.optString("stop_reason"))) break;
            // 서버 검색이 길어져 중간에 멈춘 경우 이어서 요청
            messages.put(new JSONObject().put("role", "assistant").put("content", blocks));
        }
        r.text = sb.toString().trim();
        return r;
    }

    // ---------------- 논문 검색 (Semantic Scholar, 키 불필요) ----------------
    private List<Link> searchPapers(String q) throws Exception {
        String url = "https://api.semanticscholar.org/graph/v1/paper/search?limit=5&fields=title,year,url,citationCount&query="
                + URLEncoder.encode(q, "UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        List<Link> out = new ArrayList<>();
        if (c.getResponseCode() != 200) return out;
        JSONArray data = new JSONObject(read(c.getInputStream())).optJSONArray("data");
        if (data == null) return out;
        for (int i = 0; i < data.length(); i++) {
            JSONObject p = data.getJSONObject(i);
            String t = "📄 " + p.optString("title") + (p.has("year") && !p.isNull("year") ? " (" + p.optInt("year") + ")" : "")
                    + " · 인용 " + p.optInt("citationCount");
            out.add(new Link(t, p.optString("url")));
        }
        return out;
    }

    // ---------------- 공통 ----------------
    private static void addLink(Result r, String title, String url) {
        if (url == null || url.isEmpty()) return;
        for (Link l : r.links) if (l.url.equals(url)) return;
        r.links.add(new Link(title, url));
    }

    private static JSONObject post(String url, Map<String, String> headers, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(120000);
        c.setDoOutput(true);
        c.setRequestProperty("content-type", "application/json");
        for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
        try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        String text = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
        if (code >= 400) {
            String msg = text;
            try {
                JSONObject err = new JSONObject(text).optJSONObject("error");
                if (err != null) msg = err.optString("message", text);
            } catch (Exception ignored) { }
            throw new Exception(friendly(code) + "\n(" + code + ") " + msg);
        }
        return new JSONObject(text);
    }

    private static String friendly(int code) {
        if (code == 400) return "요청 오류예요. 모델 이름이 맞는지 확인해 주세요.";
        if (code == 401 || code == 403) return "API 키가 올바르지 않아요.";
        if (code == 404) return "모델을 찾을 수 없어요. 설정에서 모델 이름을 확인해 주세요.";
        if (code == 429) return "사용 한도를 넘었어요. 잠시 후 다시 시도해 주세요.";
        if (code >= 500) return "AI 서버가 잠시 불안정해요.";
        return "오류가 났어요.";
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
